﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace RestDemo.Models
{
    public class Bike
    {
        // <id>749</id><color>Red</color><category>Road</category><size>62</size><price>3578.27</price>

        public int id { get; set; }
        public string color { get; set; }
        public string category { get; set; }
        public int size { get; set; }
        public float price { get; set; }
    }

    public class BikeData
    {

        public List<Bike> GetBikeData()
        {
            string thedata = @"
[
         {
            ""id"": ""749"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""62"",
            ""price"": ""3578.27""
         },
         {
            ""id"": ""750"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""3578.27""
         },
         {
            ""id"": ""751"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""3578.27""
         },
         {
            ""id"": ""752"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""3578.27""
         },
         {
            ""id"": ""753"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""56"",
            ""price"": ""3578.27""
         },
         {
            ""id"": ""754"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""1457.99""
         },
         {
            ""id"": ""755"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""60"",
            ""price"": ""1457.99""
         },
         {
            ""id"": ""756"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""1457.99""
         },
         {
            ""id"": ""757"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""1457.99""
         },
         {
            ""id"": ""758"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""1457.99""
         },
         {
            ""id"": ""759"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""760"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""60"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""761"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""62"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""762"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""763"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""764"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""765"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""766"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""60"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""767"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""62"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""768"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""769"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""770"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""782.99""
         },
         {
            ""id"": ""771"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""3399.99""
         },
         {
            ""id"": ""772"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""3399.99""
         },
         {
            ""id"": ""773"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""44"",
            ""price"": ""3399.99""
         },
         {
            ""id"": ""774"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""48"",
            ""price"": ""3399.99""
         },
         {
            ""id"": ""775"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""3374.99""
         },
         {
            ""id"": ""776"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""3374.99""
         },
         {
            ""id"": ""777"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""44"",
            ""price"": ""3374.99""
         },
         {
            ""id"": ""778"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""48"",
            ""price"": ""3374.99""
         },
         {
            ""id"": ""779"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""2319.99""
         },
         {
            ""id"": ""780"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""2319.99""
         },
         {
            ""id"": ""781"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""46"",
            ""price"": ""2319.99""
         },
         {
            ""id"": ""782"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""2294.99""
         },
         {
            ""id"": ""783"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""2294.99""
         },
         {
            ""id"": ""784"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""46"",
            ""price"": ""2294.99""
         },
         {
            ""id"": ""785"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""1079.99""
         },
         {
            ""id"": ""786"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""40"",
            ""price"": ""1079.99""
         },
         {
            ""id"": ""787"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""44"",
            ""price"": ""1079.99""
         },
         {
            ""id"": ""788"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""48"",
            ""price"": ""1079.99""
         },
         {
            ""id"": ""789"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""790"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""791"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""792"",
            ""color"": ""Red"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""793"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""794"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""795"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""796"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""2443.35""
         },
         {
            ""id"": ""797"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""38"",
            ""price"": ""1120.49""
         },
         {
            ""id"": ""798"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""40"",
            ""price"": ""1120.49""
         },
         {
            ""id"": ""799"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""42"",
            ""price"": ""1120.49""
         },
         {
            ""id"": ""800"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""1120.49""
         },
         {
            ""id"": ""801"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""1120.49""
         },
         {
            ""id"": ""953"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""60"",
            ""price"": ""1214.85""
         },
         {
            ""id"": ""954"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""46"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""955"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""50"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""956"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""54"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""957"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""60"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""958"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""54"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""959"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""58"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""960"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""62"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""961"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""44"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""962"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""50"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""963"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""54"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""964"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""58"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""965"",
            ""color"": ""Yellow"",
            ""category"": ""Touring"",
            ""size"": ""62"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""966"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""46"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""967"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""50"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""968"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""54"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""969"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""60"",
            ""price"": ""2384.07""
         },
         {
            ""id"": ""970"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""46"",
            ""price"": ""1214.85""
         },
         {
            ""id"": ""971"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""50"",
            ""price"": ""1214.85""
         },
         {
            ""id"": ""972"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""54"",
            ""price"": ""1214.85""
         },
         {
            ""id"": ""973"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""40"",
            ""price"": ""1700.99""
         },
         {
            ""id"": ""974"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""42"",
            ""price"": ""1700.99""
         },
         {
            ""id"": ""975"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""1700.99""
         },
         {
            ""id"": ""976"",
            ""color"": ""Yellow"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""1700.99""
         },
         {
            ""id"": ""977"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""58"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""978"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""44"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""979"",
            ""color"": ""Blue"",
            ""category"": ""Touring"",
            ""size"": ""50"",
            ""price"": ""742.35""
         },
         {
            ""id"": ""980"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""38"",
            ""price"": ""769.49""
         },
         {
            ""id"": ""981"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""40"",
            ""price"": ""769.49""
         },
         {
            ""id"": ""982"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""769.49""
         },
         {
            ""id"": ""983"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""46"",
            ""price"": ""769.49""
         },
         {
            ""id"": ""984"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""40"",
            ""price"": ""564.99""
         },
         {
            ""id"": ""985"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""564.99""
         },
         {
            ""id"": ""986"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""44"",
            ""price"": ""564.99""
         },
         {
            ""id"": ""987"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""48"",
            ""price"": ""564.99""
         },
         {
            ""id"": ""988"",
            ""color"": ""Silver"",
            ""category"": ""Mountain"",
            ""size"": ""52"",
            ""price"": ""564.99""
         },
         {
            ""id"": ""989"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""40"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""990"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""42"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""991"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""44"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""992"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""48"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""993"",
            ""color"": ""Black"",
            ""category"": ""Mountain"",
            ""size"": ""52"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""997"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""44"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""998"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""48"",
            ""price"": ""539.99""
         },
         {
            ""id"": ""999"",
            ""color"": ""Black"",
            ""category"": ""Road"",
            ""size"": ""52"",
            ""price"": ""539.99""
         }
      ]
";
            var path = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/SampleData.json");

            if (File.Exists(path))
            {
                thedata = File.ReadAllText(path);
            }
            else
            {
                File.WriteAllText(path, thedata);
            }

            //Newtonsoft.Json.Linq.JObject jObject = Newtonsoft.Json.Linq.JObject.Parse(thedata);
            Newtonsoft.Json.Linq.JArray jObject = Newtonsoft.Json.Linq.JArray.Parse(thedata);
            
            return jObject.ToObject<List<Bike>>();
        }
    }



}