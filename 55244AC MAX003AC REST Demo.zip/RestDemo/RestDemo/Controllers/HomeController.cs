﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace RestDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            return View();
        }

        public ActionResult Test()
        {
            var path = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/SampleData.json");

            if (System.IO.File.Exists(path))
            {
                return Content("file found");
            }
            else
            {
                return Content("file not found");
            }

            return Content("");
        }


        //  http://demoserver/home/ClearData
        public ActionResult ClearData()
        {
            var path = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/SampleData.json");

            System.IO.File.Delete(path);

            return Content("Sample data deleted. New sample data will be created on the first REST request.");
        }
    }
}
