﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Web.Http.OData.Query;
using System.Web.Http.OData.Routing;
using RestDemo.Models;
using Microsoft.Data.OData;
using System.IO;
using System.Web.Http.Cors;

namespace RestDemo.Controllers
{
    /*
    The WebApiConfig class may require additional changes to add a route for this controller. Merge these statements into the Register method of the WebApiConfig class as applicable. Note that OData URLs are case sensitive.

    using System.Web.Http.OData.Builder;
    using System.Web.Http.OData.Extensions;
    using RestDemo.Models;
    ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
    builder.EntitySet<Bike>("Bikes");
    config.Routes.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());
    */
    [AllowAnonymous]
    [EnableCors(origins: "*", headers: "*", methods: "*", exposedHeaders: "*")]
    public class BikesController : ODataController
    {
        private static ODataValidationSettings _validationSettings = new ODataValidationSettings();

        BikeData BikesCollection = new BikeData();

        // GET: odata/Bikes
        [EnableQuery]
        public IQueryable<Bike> GetBikes()
        {
            
            var data = BikesCollection.GetBikeData();
            return data.AsQueryable();
        }

        // GET: odata/Bikes(5)
        [EnableQuery]
        public Bike GetBike([FromODataUri] int key)
        {
            var data = BikesCollection.GetBikeData().Where(b => b.id==key).FirstOrDefault();
            return data;
        }

        // PUT: odata/Bikes(5)
        public IHttpActionResult Put([FromODataUri] int key, Delta<Bike> delta)
        {
            Validate(delta.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // TODO: Get the entity here.

            // delta.Put(bike);

            // TODO: Save the patched entity.

            // return Updated(bike);
            return StatusCode(HttpStatusCode.NotImplemented);
        }

        // POST: odata/Bikes
        public Bike Post(Bike bike)
        {

            var data = BikesCollection.GetBikeData();
            var lastid = data.Max(x => x.id);
            bike.id = lastid + 1;
            data.Add(bike);

            var path = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/SampleData.json");

            string thedata = Newtonsoft.Json.JsonConvert.SerializeObject(data,Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(path, thedata);
            
            return data.Where(b => b.id == bike.id).FirstOrDefault();
        }

        // PATCH: odata/Bikes(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public IHttpActionResult Patch([FromODataUri] int key, Delta<Bike> delta)
        {
            Validate(delta.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // TODO: Get the entity here.

            // delta.Patch(bike);

            // TODO: Save the patched entity.

            // return Updated(bike);
            return StatusCode(HttpStatusCode.NotImplemented);
        }

        // DELETE: odata/Bikes(5)
        public IHttpActionResult Delete([FromODataUri] int key)
        {
            var data = BikesCollection.GetBikeData();
            var biketodelete = BikesCollection.GetBikeData().Find(b => b.id == key);
            if (biketodelete == null) { return NotFound(); }
            data.Remove(biketodelete);

            var path = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/SampleData.json");

            string thedata = Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(path, thedata);

            return Ok("Deleted");
        }
    }
}
